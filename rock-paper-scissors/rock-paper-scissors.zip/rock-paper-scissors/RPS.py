def player(prev_play, opponent_history=[]):
    """
    Multi-strategy player to beat Quincy, Abbey, Kris, and Mrugesh
    """

    # Initialize on first call or reset
    if not prev_play:
        opponent_history.clear()
        if hasattr(player, "my_history"):
            player.my_history = []
        player.my_history = []
    else:
        opponent_history.append(prev_play)

    # Initialize player history if needed
    if not hasattr(player, "my_history"):
        player.my_history = []

    # What beats what
    ideal_response = {'P': 'S', 'R': 'P', 'S': 'R'}

    n = len(opponent_history)
    guess = "P"

    # === COUNTER QUINCY (Priority 1) - Try multiple patterns ===
    if n >= 2:
        # Try different possible Quincy patterns
        quincy_patterns = [
            ["R", "R", "P", "P", "S"],  # Pattern starting at counter=1
            ["R", "P", "P", "S",
             "S"],  # Pattern starting at counter=0 (alternative)
        ]

        best_match = 0
        best_pattern = None
        best_offset = 0

        for pattern in quincy_patterns:
            for offset in range(5):
                matches = 0
                check_len = min(30, n)
                for i in range(check_len):
                    expected = pattern[(i + offset) % 5]
                    if opponent_history[i] == expected:
                        matches += 1

                match_rate = matches / check_len if check_len > 0 else 0
                if match_rate > best_match:
                    best_match = match_rate
                    best_pattern = pattern
                    best_offset = offset

        # If we found a strong Quincy pattern, use it
        if best_match > 0.60 and n >= 5:
            predicted = best_pattern[(n + best_offset) % 5]
            guess = ideal_response[predicted]
            player.my_history.append(guess)
            return guess

    # === COUNTER ABBEY (Priority 2) ===
    if len(player.my_history) >= 2 and n >= 3:
        last_two = "".join(player.my_history[-2:])

        abbey_counter = {
            "RP": "P",
            "PS": "S",
            "SR": "R",
            "PR": "R",
            "SP": "P",
            "RS": "S",
            "PP": "S",
            "SS": "R",
            "RR": "P"
        }

        abbey_will_play = abbey_counter.get(last_two, "R")

        # Check if Abbey pattern holds
        abbey_correct = 0
        check_len = min(12, len(player.my_history) - 1)

        for i in range(check_len):
            if len(player.my_history) > i + 2 and len(opponent_history) > i:
                prev_two = "".join(player.my_history[-(i + 3):-(i + 1)])
                expected_abbey = abbey_counter.get(prev_two, "R")
                actual_opp = opponent_history[-(i + 1)]
                if expected_abbey == actual_opp:
                    abbey_correct += 1

        if check_len > 0 and abbey_correct / check_len > 0.50:
            guess = ideal_response[abbey_will_play]
            player.my_history.append(guess)
            return guess

    # === COUNTER KRIS (Priority 3) ===
    if len(player.my_history) >= 5 and n >= 5:
        counts = {"R": 0, "P": 0, "S": 0}
        for m in player.my_history:
            if m in counts:
                counts[m] += 1

        my_most_common = max(counts, key=counts.get)
        kris_would_play = ideal_response[my_most_common]

        # Check if Kris pattern holds
        check_len = min(18, n)
        kris_correct = sum(1 for m in opponent_history[-check_len:]
                           if m == kris_would_play)

        if kris_correct / check_len >= 0.45:
            guess = ideal_response[kris_would_play]
            player.my_history.append(guess)
            return guess

    # === COUNTER MRUGESH (Priority 4) ===
    if len(player.my_history) >= 4 and n >= 4:
        last_3 = player.my_history[-3:]

        # Find if this pattern appeared before
        for i in range(len(player.my_history) - 4):
            if player.my_history[i:i + 3] == last_3:
                our_next_move = player.my_history[i + 3]
                mrugesh_move = ideal_response[our_next_move]
                guess = ideal_response[mrugesh_move]
                player.my_history.append(guess)
                return guess

    # === FALLBACK ===
    if n > 2:
        recent = opponent_history[-min(25, n):]
        opp_counts = {"R": 0, "P": 0, "S": 0}
        for m in recent:
            if m in opp_counts:
                opp_counts[m] += 1
        most_common_opp = max(opp_counts, key=opp_counts.get)
        guess = ideal_response[most_common_opp]

    player.my_history.append(guess)
    return guess
