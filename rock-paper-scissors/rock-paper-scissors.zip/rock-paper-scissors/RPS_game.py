import random

moves = ["R", "P", "S"]


def play(player1, player2, num_games=1000, verbose=False):
    p1_prev, p2_prev = "", ""
    p1_hist, p2_hist = [], []
    p1_wins = p2_wins = ties = 0

    for _ in range(num_games):
        p1_move = player1(p2_prev, p2_hist)
        p2_move = player2(p1_prev, p1_hist)

        if p1_move not in moves or p2_move not in moves:
            raise ValueError("Invalid move! Must be R, P, or S.")

        if p1_move == p2_move:
            ties += 1
        elif (p1_move == "R" and p2_move == "S") or \
             (p1_move == "P" and p2_move == "R") or \
             (p1_move == "S" and p2_move == "P"):
            p1_wins += 1
        else:
            p2_wins += 1

        p1_prev, p2_prev = p1_move, p2_move
        p1_hist.append(p1_move)
        p2_hist.append(p2_move)

        if verbose:
            print(f"Player1: {p1_move} | Player2: {p2_move}")

    return p1_wins, p2_wins, ties


# Opponent bots
def quincy(prev_opponent_play, opponent_history=[]):
    pattern = ["R", "P", "S", "R", "P"]
    return pattern[len(opponent_history) % len(pattern)]


def abbey(prev_opponent_play, opponent_history=[]):
    if not opponent_history:
        return "P"
    counter = {"R": "P", "P": "S", "S": "R"}
    return counter[prev_opponent_play]


def kris(prev_opponent_play, opponent_history=[]):
    if not opponent_history:
        return random.choice(moves)
    return prev_opponent_play


def mrugesh(prev_opponent_play, opponent_history=[]):
    if prev_opponent_play:
        opponent_history.append(prev_opponent_play)
    if not opponent_history:
        return "P"
    most_common = max(set(opponent_history), key=opponent_history.count)
    counter = {"R": "P", "P": "S", "S": "R"}
    return counter[most_common]
