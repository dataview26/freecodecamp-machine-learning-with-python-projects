from RPS import player
from RPS_game import play, quincy, abbey, kris, mrugesh


def test_player():
    opponents = [quincy, abbey, kris, mrugesh]
    for opp in opponents:
        wins, losses, ties = play(player, opp, num_games=1000, verbose=False)
        win_rate = wins / (wins + losses) if (wins + losses) else 0
        print(f"vs {opp.__name__}: {win_rate*100:.1f}% win rate")


if __name__ == "__main__":
    test_player()
